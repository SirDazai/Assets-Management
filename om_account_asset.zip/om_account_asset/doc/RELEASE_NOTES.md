## Module <om_account_asset>

#### 24.12.2021
#### Version 14.0.6.0.0
##### FIX
- asset

#### 22.12.2021
#### Version 14.0.5.0.0
##### IMP
- remove deprecated method

#### 08.12.2021
#### Version 14.0.4.0.0
##### IMP
- security
